document.querySelector('h1').addEventListener('click', ()=> {
    document.body.style.background = 'turquoise';
})